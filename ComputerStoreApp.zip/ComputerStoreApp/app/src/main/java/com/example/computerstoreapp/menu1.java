package com.example.computerstoreapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class menu1 extends AppCompatActivity {
    public TextView t1;
    public ListView l1;
    public String[] str={"Laptop","Headphones","Speakers","Special Offer","repair"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        t1=findViewById(R.id.t1);
        l1=(ListView)findViewById(R.id.l1);



        ArrayAdapter<String> adpt=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,str);
        l1.setAdapter(adpt);

        l1.setOnItemClickListener(new ListView.OnItemClickListener()
        {
            @Override

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String str1 = str[position];
                Toast.makeText(getApplicationContext(), "Loading..." + str[position], Toast.LENGTH_SHORT).show();

                if (str1.equals("Headphones")) {
                    Intent intent = new Intent(getApplicationContext(), headphone.class);

                    startActivity(intent);
                }
                else if (str1.equals("Laptop")) {
                    Intent intent = new Intent(getApplicationContext(), laptop.class);

                    startActivity(intent);
                }
                else if (str1.equals("repair")) {
                    Intent intent = new Intent(getApplicationContext(), repair.class);

                    startActivity(intent);
                }
                else if (str1.equals("Speakers")) {
                    Intent intent = new Intent(getApplicationContext(), speaker.class);

                    startActivity(intent);
                }
                else{
                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);

                    startActivity(intent);
                }

            }
        });



    }
}


