package com.example.computerstoreapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity{
  public AutoCompleteTextView atv1;
   public ImageButton ib1;
   public String[] str={"Laptop","Headphones","Speakers","Special Offer"};
    public ImageButton img1,ib2,ib3,ib4,ib5,ib6,ib7;
    public ImageButton cart_1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        atv1=(AutoCompleteTextView)findViewById(R.id.atv1);
        ib1=(ImageButton)findViewById(R.id.ib1);
        img1=findViewById(R.id.img1);
        ib2=findViewById(R.id.ib2);
        ib3=findViewById(R.id.ib3);
        ib4=findViewById(R.id.ib4);
        ib5=findViewById(R.id.ib5);
        ib6=findViewById(R.id.ib6);
        ib7=findViewById(R.id.ib7);
        cart_1=(ImageButton) findViewById(R.id.cart_1);
        atv1.setThreshold(1);
        ArrayAdapter<String> adpt=new ArrayAdapter<>(this,android.R.layout.select_dialog_item,str);
        atv1.setAdapter(adpt);
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), menu1.class);
                startActivity(intent);
            }
        });
        ib1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String str=atv1.getText().toString();
                if (str.equals("Headphones")) {
                    Intent intent = new Intent(getApplicationContext(), headphone.class);
                    startActivity(intent);
                }
                else if (str.equals("Laptop")) {
                    Intent intent = new Intent(getApplicationContext(), laptop.class);
                    startActivity(intent);
                }
                else if (str.equals("Speakers")) {
                    Intent intent = new Intent(getApplicationContext(), speaker.class);
                    startActivity(intent);
                }
                else{
                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    startActivity(intent);
                } }
        });

        ib2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), laptop.class);
                startActivity(intent);
            }
        });
        ib3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), laptop.class);
                startActivity(intent);
            }
        });
        ib4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), speaker.class);
                startActivity(intent);
            }
        });

        ib5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), speaker.class);
                startActivity(intent);
            }
        });
        ib6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), headphone.class);
                startActivity(intent);
            }
        });
        ib7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), headphone.class);
                startActivity(intent);
            }
        });
        cart_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(),cart.class);
            }
        });
    }
}


