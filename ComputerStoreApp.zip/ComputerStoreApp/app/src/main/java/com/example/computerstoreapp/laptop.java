package com.example.computerstoreapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class laptop extends AppCompatActivity {
    public Button b1, b2, b3, b4, b5, b6, b7, b8;
    public ArrayList<String> al = new ArrayList<String>();
    public String[] listelements = new String[]{};
    public TextView tv, t10, t2;
    public TextView f3_t1, f3_t2, f4_t1, f4_t2, f5_t1, f5_t2, f6_t1, f6_t2, f7_t1, f7_t2, f8_t1, f8_t2;
    public ImageButton car;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_laptop);
        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        tv = findViewById(R.id.t1);
        t2 = findViewById(R.id.t2);
        t10 = findViewById(R.id.t10);
        car = findViewById(R.id.car);
        f3_t1 = findViewById(R.id.f3_t1);
        f3_t2 = findViewById(R.id.f3_t2);
        f4_t1 = findViewById(R.id.f4_t1);
        f4_t2 = findViewById(R.id.f4_t2);
        f5_t1 = findViewById(R.id.f5_t1);
        f5_t2 = findViewById(R.id.f5_t2);
        f6_t1 = findViewById(R.id.f6_t1);
        f6_t2 = findViewById(R.id.f6_t2);
        f7_t1 = findViewById(R.id.f7_t1);
        f7_t2 = findViewById(R.id.f7_t2);
        f8_t1 = findViewById(R.id.f8_t1);
        f8_t2 = findViewById(R.id.f8_t2);

        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);

        final List<String> ListElementList = new ArrayList<String>(Arrays.asList(listelements));


        car.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);
                startActivity(i);
            }

        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str1 = tv.getText().toString();
                String str2 = t2.getText().toString();
                String str3 = str1 + "  " + "with price" + str2;
                al.add(str3);
                ListElementList.add(str3);
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                al.add(t10.getText().toString());
                ListElementList.add(t10.getText().toString());
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str1 = f3_t1.getText().toString();
                String str2 = f3_t2.getText().toString();
                String str3 = str1 + "  " + "with price" + str2;
                al.add(str3);
                ListElementList.add(str3);
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str1 = f4_t1.getText().toString();
                String str2 = f4_t2.getText().toString();
                String str3 = str1 + "  " + "with price" + str2;
                al.add(str3);
                ListElementList.add(str3);
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str1 = f5_t1.getText().toString();
                String str2 = f5_t2.getText().toString();
                String str3 = str1 + "  " + "with price" + str2;
                al.add(str3);
                ListElementList.add(str3);
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str1 = f6_t1.getText().toString();
                String str2 = f6_t2.getText().toString();
                String str3 = str1 + "  " + "with price" + str2;
                al.add(str3);
                ListElementList.add(str3);
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str1 = f7_t1.getText().toString();
                String str2 = f7_t2.getText().toString();
                String str3 = str1 + "  " + "with price" + str2;
                al.add(str3);
                ListElementList.add(str3);
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String str1 = f8_t1.getText().toString();
                String str2 = f8_t2.getText().toString();
                String str3 = str1 + "  " + "with price" + str2;
                al.add(str3);
                ListElementList.add(str3);
                Toast.makeText(getApplicationContext(), "Product added", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), cart.class);
                i.putExtra("array", al);


            }
        });

    }
}
