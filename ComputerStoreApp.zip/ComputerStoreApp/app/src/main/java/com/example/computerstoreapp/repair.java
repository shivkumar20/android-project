package com.example.computerstoreapp;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;
import android.os.Bundle;

public class repair extends AppCompatActivity {
    private Button btns;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repair);
        btns =(Button)findViewById(R.id.btns);
        btns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPopUpWindow();

            }


        });
    }

    private void openPopUpWindow() {
        Intent popupwindow = new Intent(repair.this,popup.class);
        startActivity(popupwindow);
    }

}